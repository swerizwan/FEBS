package cc.mrbird.febs.system.mapper;

import cc.mrbird.febs.system.entity.UserDataPermission;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author MrBird
 */
public interface UserDataPermissionMapper extends BaseMapper<UserDataPermission> {

}
