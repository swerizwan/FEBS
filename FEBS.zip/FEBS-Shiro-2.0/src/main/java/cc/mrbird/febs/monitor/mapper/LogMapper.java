package cc.mrbird.febs.monitor.mapper;

import cc.mrbird.febs.monitor.entity.SystemLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author MrBird
 */
public interface LogMapper extends BaseMapper<SystemLog> {

}
