package cc.mrbird.febs.generator.entity;

/**
 * @author MrBird
 */
public class FieldType {

    public static final String DATE = "date";
    public static final String DATETIME = "datetime";
    public static final String TIMESTAMP = "timestamp";
    public static final String DECIMAL = "decimal";
    public static final String NUMERIC = "numeric";
}
