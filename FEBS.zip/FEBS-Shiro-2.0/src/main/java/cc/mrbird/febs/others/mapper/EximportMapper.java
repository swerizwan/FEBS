package cc.mrbird.febs.others.mapper;

import cc.mrbird.febs.others.entity.Eximport;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author MrBird
 */
public interface EximportMapper extends BaseMapper<Eximport> {

}
